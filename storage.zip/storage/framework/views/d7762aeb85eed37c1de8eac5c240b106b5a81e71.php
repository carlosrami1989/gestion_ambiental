<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'BSPI')); ?></title>

    <!-- Icono de la Pestaña -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/icono.png')); ?>">

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Estilo del Login CoreUI -->
    <link rel="stylesheet" href="css/simple-line-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.0/dist/alpine.js" defer></script>
</head>

<body>
    <div id="app" class="app flex-row align-items-center">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\controlclinico\resources\views/layouts/guest.blade.php ENDPATH**/ ?>