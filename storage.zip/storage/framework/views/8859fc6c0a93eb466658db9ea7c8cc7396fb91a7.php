<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'BSPI')); ?></title>

    <!-- Icono de la Pestaña -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/icono.png')); ?>">

    <!-- Plantilla General de los CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla.css')); ?>">

    <!-- Evitar ataques X-CSRF-TOKEN -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.0/dist/alpine.js" defer></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    

    <!-- Main Sidebar Container -->
     
    <div id="app">
    <v-app  >
    <home></home>
    </v-app>
    </div>
 

    </body>
    <!-- App JS de Vue -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <!-- Plantilla General de los JS -->
    <script src="<?php echo e(asset('js/plantilla.js')); ?>"></script>
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@4.x/css/materialdesignicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="//cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">


</html>
<?php /**PATH C:\xampp\htdocs\controlclinico\resources\views/layouts/app.blade.php ENDPATH**/ ?>