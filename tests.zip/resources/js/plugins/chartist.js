import Vue from 'vue'



Vue.use(require('vue-chartist'));