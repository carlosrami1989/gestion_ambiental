<?php

return [
    //CUANDO SE USA DIRECTORIO VIRTUAL
   // 'router_prefix' => '/majoma_sistema',
    //CUANDO SE USA SITIO WEB
    'router_prefix' => '/',

    
];
