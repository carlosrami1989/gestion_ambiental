 

<body>
 
    
<div ><?php echo e($titulo); ?></div>
<table  >
    <tr >
        <td>Nº registro</td>
        <td>Fecha de registro</td>
        <td>Descripcion de Desechos</td>
        <td>Responsable del área</td>
        <td>Departamento</td>
         
        <td>Kg.</td>
        
        
    </tr>
    <?php
    $cont = 0;
    ?>
    <?php for($i=0; $i < sizeof($lista) ; $i++): ?> <tr>
        <?php
        $cont = $i;
        $cont +=1;

        ?>
        <td   > <?php echo e($cont); ?></td>
        <td > <?php echo e($lista[$i]->created_at); ?></td>
               <td > <?php echo e($lista[$i]->des_clasificacion_desechos_des); ?></td>
        <td > <?php echo e($lista[$i]->responsable_apellido); ?> <?php echo e($lista[$i]->responsable_nombre); ?></td>
        <td > <?php echo e($lista[$i]->departamento); ?></td>
        
        <td > <?php echo e($lista[$i]->peso); ?></td>
        
       
       
        </tr>

        <?php endfor; ?>


</table>




<table style="position: fixed;bottom: 0px;">
    <thead>
        <tr>
            
        </tr>
    </thead>
</table>



</body>

</html>
<?php /**PATH C:\inetpub\wwwroot\gestion_mantenimiento\resources\views/reports/excel.blade.php ENDPATH**/ ?>